package com.example.demo.controller;

import com.example.demo.service.ClientEnrollmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ClientEnrollmentController {

    @Autowired
    ClientEnrollmentService clientEnrollmentService;

    @DeleteMapping(value = "/enrollemnts/{orgOid}", produces = "application/json")
    public ResponseEntity<Object> contacts(@PathVariable("orgOid") String orgOid) {
        try{
            clientEnrollmentService.deleteEnrollments(orgOid);
            return ResponseEntity.ok().body("Suuccess");
        }catch (Exception e){
            ResponseEntity<Object> responseEntity = ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
                    .body("Unable to Delete the Enrollments");
            return ResponseEntity.ok().body(responseEntity);
        }

    }
}
