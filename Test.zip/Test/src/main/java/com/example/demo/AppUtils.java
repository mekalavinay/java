package com.example.demo;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.UUID;

@Slf4j
@Service
public class AppUtils {
	
RestTemplate restTemplate;
private static final String PATTERN_WITH_TIMEZONE = "yyyy-MM-dd HH:mm:ss";


	public static <T> ResponseEntity<T> callApi(String desc, String url, HttpMethod method,
                                                @Nullable HttpEntity<?> requestEntity, Class<T> responseType, boolean isLogDebug, Object... uriVariables) throws RestClientException
    {    
        
        if(requestEntity == null) requestEntity = HttpEntity.EMPTY;        
        String methodName = method.name();
        
        log.info("Invoking {} call to {} API with URL: {}",methodName, desc, url);
        log.info("Invoking {} call to {} API with Headers: {}",methodName, desc, requestEntity.getHeaders());
        log.info("Invoking {} call to {} API with Payload: {}",methodName, desc, requestEntity.getBody());

        ResponseEntity<T> response = new RestTemplate().exchange(url,method,requestEntity,responseType, uriVariables);
        log.info("Response code of {} API : {}",desc, response.getStatusCode());
        
        if(isLogDebug)        	
        	log.info("Response of {} API : {}",desc, response);
        
        return response;        
        
    }
	
	public static String generateRandomUUID() {
		var uuid = UUID.randomUUID().toString();//Example: 4af0541c-fe55-4090-9327-9116e263d82b
		log.info("Generated random UUID is : {}",uuid);
		return uuid;
	}	

	private AppUtils() {

    }

}
