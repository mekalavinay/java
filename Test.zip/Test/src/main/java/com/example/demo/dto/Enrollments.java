package com.example.demo.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Enrollments {

@JsonProperty("data")
private List<Datum> data;
@JsonProperty("isReadOnly")
private Boolean isReadOnly;
@JsonProperty("requestResponseId")
private String requestResponseId;
@JsonProperty("serverTimeTaken")
private String serverTimeTaken;

}