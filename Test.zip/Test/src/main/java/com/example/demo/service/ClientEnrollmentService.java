package com.example.demo.service;

import com.example.demo.AppUtils;
import com.example.demo.dto.CompanyInfo;
import com.example.demo.dto.EnrollemntDTO;
import com.example.demo.dto.Enrollments;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ClientEnrollmentService {

    public Enrollments getEnrollemnts(String orgOid){
        Enrollments enrollments = null;
        var uriBuilder = UriComponentsBuilder.fromHttpUrl("http://mascsr.fit.oneadp.com/mascsr/wfn/compliance/metaservices/ei9/clientEnrollment/clientList/12345");
        var headers = new HttpHeaders();
        headers.add("OrgOID", orgOid);
        HttpEntity<Object> requestEntity = new HttpEntity<>(headers);
        ResponseEntity<Enrollments> res = AppUtils.callApi("ENrollment Details",
                uriBuilder.toUriString(), HttpMethod.GET, requestEntity, Enrollments.class, true);
        return res.getBody();
    }

    public void deleteEnrollments(String orgOid){
        Enrollments enrollments = getEnrollemnts(orgOid);
        if(!CollectionUtils.isEmpty(enrollments.getData())){
            List<String> ooidsList = enrollments.getData().stream().map(datum -> datum.getOid()).collect(Collectors.toList());
            if(!CollectionUtils.isEmpty(ooidsList)){
                ooidsList.forEach(oid->{
                    EnrollemntDTO enrollemntDTO = new EnrollemntDTO();
                    CompanyInfo companyInfo =  new CompanyInfo();
                    companyInfo.setOid(oid);
                    enrollemntDTO.setCompanyInfo(companyInfo);
                    deleteEnrollment(enrollemntDTO,orgOid);
                });


            }
        }
    }

    public void deleteEnrollment(EnrollemntDTO enrollemntDTO,String orgOid){
        var uriBuilder = UriComponentsBuilder.fromHttpUrl("http://mascsr.fit.oneadp.com/mascsr/wfn/compliance/metaservices/ei9/clientEnrollment/deleteCompany");
        var headers = new HttpHeaders();
        headers.add("OrgOID", orgOid);
        headers.add("Content-Type", "application/json");
        HttpEntity<Object> requestEntity = new HttpEntity<>(enrollemntDTO,headers);
        ResponseEntity<String> res = AppUtils.callApi("ENrollment Details",
                uriBuilder.toUriString(), HttpMethod.DELETE, requestEntity, String.class, true);
        log.info(res.getBody());
    }
}
