package com.example.demo.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class StatusType {

@JsonProperty("oid")
private String oid;
@JsonProperty("category")
private String category;
@JsonProperty("code")
private String code;
@JsonProperty("description")
private String description;
@JsonProperty("idsKey")
private String idsKey;
@JsonProperty("active")
private Integer active;
@JsonProperty("version")
private String version;
@JsonProperty("modifiedOn")
private String modifiedOn;

}