package com.example.demo.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Datum {

@JsonProperty("oid")
private String oid;
@JsonProperty("organziationOid")
private String organziationOid;
@JsonProperty("companyName")
private String companyName;
@JsonProperty("idNum")
private String idNum;
@JsonProperty("totalEmpRangeOid")
private String totalEmpRangeOid;
@JsonProperty("naicsCode")
private String naicsCode;
@JsonProperty("mailAddrSame")
private Boolean mailAddrSame;
@JsonProperty("employerCategoryCode")
private String employerCategoryCode;
@JsonProperty("statusOid")
private String statusOid;
@JsonProperty("statusType")
private StatusType statusType;
@JsonProperty("uaMode")
private Boolean uaMode;

}